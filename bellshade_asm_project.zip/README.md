# 🧾 Simple Assembly: Print Text with NASM (32-bit)

Program ini menampilkan teks `"bellshade"` ke layar menggunakan bahasa Assembly NASM untuk arsitektur 32-bit di Linux.

## 📁 File
- `print_bellshade.asm` — kode sumber program utama

---

## ⚙️ Cara Compile dan Jalankan

```bash
nasm -f elf32 -o print_bellshade.o print_bellshade.asm
ld -m elf_i386 -o print_bellshade print_bellshade.o
./print_bellshade
```

> 💡 Pastikan sistem kamu mendukung arsitektur 32-bit (`i386`). Jika menggunakan OS 64-bit, kamu mungkin perlu menginstall 32-bit libraries (misalnya: `sudo apt install gcc-multilib`).

---

## 🔍 Penjelasan Kode

```nasm
section .data
msg     db      'bellshade', 0xA
len     equ     $ - msg
```

- Bagian `.data` menyimpan string yang akan ditampilkan.
- `$ - msg` otomatis menghitung panjang string.

```nasm
section .text
global _start
```

- `.text` adalah tempat instruksi program.
- `_start` adalah titik masuk program (entry point).

```nasm
_start:
    mov edx, len
    mov ecx, msg
    mov ebx, 1
    mov eax, 4
    int 0x80
```

- Menulis string ke layar menggunakan syscall `sys_write` (nomor 4).

```nasm
    mov eax, 1
    xor ebx, ebx
    int 0x80
```

- Keluar dari program menggunakan `sys_exit` (nomor 1), dengan exit code 0.

---

## 💡 Referensi Syscall Linux (32-bit)

| Syscall      | Nomor | Keterangan           |
|--------------|-------|----------------------|
| `sys_write`  | 4     | Tulis ke stdout      |
| `sys_exit`   | 1     | Keluar dari program  |

---

## 📦 Lisensi

Proyek ini bebas digunakan untuk belajar dan eksperimen. Jangan lupa kasih ⭐ kalau kamu suka atau terbantu!